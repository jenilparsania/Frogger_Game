package demo;

public class GameProperties {
	public static final int SCREEN_HEIGHT = 700;
	public static final int SCREEN_WIDTH = 810;
	public static final int CHARACTER_STEP = 42;
	public static final String BG_IMAGE = "bg_800x500.png";
	public static final int x_left = 7;
	public static final int y_left = 533;
	public static final int x_right = 763;
	public static final int y_low = 533;
	public static final int y_top = 29;
	public static final int y_safe = 245;
	
	
	// as we changed the rectangle even the dimensions changed as well 
	
	
	
	/*
	 * safe zone : y=281
	 * one step after safe-zone:  y = 239 
	 * 
	 * 
	 * */
	
	/*
	 *
	 * Add a stop button , to stop the game
	 * change the font size of the score 
	 * 
	 */
}
